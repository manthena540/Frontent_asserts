# Frontend UI Assets & Standards

A reusable reference library for frontend developers.

Use this folder whenever you start a new UI, website, dashboard, landing page, portfolio, SaaS product, ecommerce site, or web app.

## Quick workflow

1. Understand the project and ask the client/TL questions.
2. Choose the website type and UX direction.
3. Select typography, colors, icons and imagery.
4. Choose animation and supporting libraries.
5. Build responsive states.
6. Check accessibility, performance and consistency.
7. Run the final UI/UX checklist.

## Sections

- `01-icons/` — free, paid and animated icon sources
- `02-text/` — content and microcopy guidance
- `03-colors/` — palette tools and color-system guidance
- `04-images/` — free/paid image and illustration sources
- `05-plugins-libraries/` — frontend/UI libraries
- `06-ux-improvements/` — practical UX checks
- `07-client-tl-questions/` — questions to ask before and during development
- `08-animation/` — animation sources and usage rules
- `09-project-checklists/` — reusable checklists

## Golden rule

Do not collect resources just because they look good. Record:
- What the resource is for
- License / pricing
- When to use it
- How to install or use it
- The source URL
- Any attribution requirement
